import { Component, Input } from '@angular/core';
import { Customers } from './customers';
import { CustomersService } from './customers.service';
@Component({
    selector: 'update',
    templateUrl: '',
    styleUrls: ['']
})
export class UpdateCustomerComponent{
    @Input()
    selectedProduct: Customers;
    constructor(private custService: CustomersService) { 
        
    }

}
