export class Customers{
    id:number;
    first_name:string;
    last_name:string;
    gender:string;
    address:string;
    city:string;
    state:string;

    constructor(first_name:string,last_name:string,gender:string,address:string,city:string,state:string){
        
        this.first_name=first_name;
        this.last_name=last_name;
        this.gender=gender;
        this.address=address;
        this.city=city;
        this.state=state;
    }

}