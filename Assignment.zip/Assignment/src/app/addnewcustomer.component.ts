import { Component } from '@angular/core';
import { CustomersService } from './customers.service';
import { HttpClient, HttpResponse} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import sampledata from '../assets/data.json';
import { Customers } from './customers';
import 'rxjs-compat/add/operator/map';
import { error } from '@angular/compiler/src/util';

@Component({
    selector: 'addnew',
    templateUrl: './addnewcustomer.component.html',
    styleUrls: ['./addnewcustomer.component.css']
})
export class AddNewCustomerComponent{
    CustomerObj:Customers;
    confirmationString = "New Customer has Been Added";
  isAdded:boolean = false;
  // private url:string="/assets/data.json";
    constructor(private http:HttpClient, private service:CustomersService) {
        
     }

     
     onSubmit(customerData){
      //  this.CustomerObj = {
      //      "id":customerData.id,
      //   "first_name" : customerData.first_name,
      //   "last_name" : customerData.last_name,
      //   "gender":customerData.gender,
      //   "address" : customerData.address,
      //   "city" : customerData.city,
      //   "state" : customerData.state
      //  }     

      this.CustomerObj=new Customers(customerData.first_name,customerData.last_name,customerData.gender,customerData.address,customerData.city,customerData.state);
      this.service.addCustomer(this.CustomerObj).subscribe(data=> alert('Success!!'),error=> alert('Error!!'+error));
      //  console.log(customerData);
      //  this.http.post(this.url , this.CustomerObj).subscribe(res => {console.log(res);this.isAdded=true;})
    // sampledata.push(this.CustomerObj);
     }

     
}