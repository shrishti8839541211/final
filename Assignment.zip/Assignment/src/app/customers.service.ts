// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class CustomersService {

//   constructor() { }
// }



import { Injectable } from '@angular/core';
import { Customers } from './customers';
import { Subject } from 'rxjs-compat/Subject';
import { HttpClient, HttpResponse} from '@angular/common/http';
import { Observable } from 'rxjs-compat/Observable';
import 'rxjs-compat/add/operator/map';

@Injectable()
export class CustomersService{
    // customer:Customers[]=[];
    // cart:Customers[];
    // res:Customers[];
    // cust:Customers[]=[];
    myCart:any;
    public len:number;
    private url:string="http://localhost:3000/customer/";
    private cartSource  =  new Subject<string>();
    constructor(private http: HttpClient) {
    
        // let p1 = new Customers(1,"./assets/images/Female.png","Michelle","Avery","Female","346 Cedar Ave.","Dallas","Texas");
        // let p2 = new Customers(2,"./assets/images/Male.png","Ward","Bell","Male","12 Ocean View St.","Dallas","Texas");
        // let p3 = new Customers(3,"./assets/images/Female.png","Robin","Cleark","Female","35632 Richmond Circle Apt B.","Los Angeles","California");
        // let p4 = new Customers(4,"./assets/images/Male.png","Pinal","Dave","Male","235235 Yaz Blvd.","Houston","Texas");
        // let p5 = new Customers(5,"./assets/images/Male.png","Albert","Einstein","Male","1 Atomic State.","Seattle","Washington");
        // let p6 = new Customers(6,"./assets/images/Female.png","Robyn","Flores","Female","5687534 Jefferson way.","Buffalo","New York");
        
        // this.customer[0] = p1;
        // this.customer[1] = p2;
        // this.customer[2] = p3;
        // this.customer[3] = p4;
        // this.customer[4] = p5;
        // this.customer[5] = p6;
        // this.getJSON().subscribe(data => {
        //     console.log(data);
        //     this.customer=JSON.stringify(data);
        // });
    }

    // ngOnInit () {
    //     this.httpService.get('../assets/data.json').subscribe(
    //       data => {
    //         this.customer = data as Customers [];	 // FILL THE ARRAY WITH DATA.
    //         console.log(this.customer[0]);
    //       },
    //       (err: HttpErrorResponse) => {
    //         console.log (err.message);
    //       }
    //     );
    //   }

    public getCustomer(): Observable<any[]> {
        return this.http.get<any[]>(this.url);
        // for(var i in this.myCart){
        //     this.len=i.length;
        // }
    //    this.myCart.subscribe(res=>{this.len=res.length;console.log(this.len)});
    //    console.log(typeof(this.len));
        // return this.myCart;
    }
    
   public addCustomer(user:any){
        return this.http.post<any>(this.url,user)
    }

    public updateCustomer(user:any){
        return this.http.put<any>(this.url+user.id,user)
    }

    // getCustomers():Customers[]{
    //     console.log(this.customer);
    //     return this.customer;
    // }

    remove(index:number):Observable<void>{
        return this.http.delete<void>(this.url+index);
    }
  }