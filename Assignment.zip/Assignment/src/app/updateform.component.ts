import { Component, OnInit } from '@angular/core';
import { CustomersService } from './customers.service';
import { Customers } from './customers';
import { ActivatedRoute } from '@angular/router';
import { HttpClient, HttpResponse} from '@angular/common/http';
import sampledata from '../../../data.json';


@Component({
  selector: 'updateform',
  templateUrl: './updateform.component.html',
  styleUrls: ['./updateform.component.css'],
  providers:[CustomersService]
})
export class UpdateFormComponent implements OnInit{
  public cust=sampledata.customer;
  public pcust:Customers;
  // private url:string="http://localhost:3000/customer";
    constructor(private route:ActivatedRoute,private service:CustomersService) {
      
     }

     ngOnInit() {
      // this.service.getCustomer().subscribe(res=>this.cust=res);
      // console.log(this.cust);

      this.route.paramMap.subscribe(para=>{
       const id=   +para.get('id');
      // console.log(id);
      this.getCustomerDetails(id);
    });
       
  }
 private getCustomerDetails(str:number){
    //  this.cust=this.service.getCustomers();
    // console.log(this.cust[2]);
     for(var i in this.cust){
      //  console.log(i);
       if(this.cust[i].id==str){
         this.pcust=this.cust[i];
        //  console.log(this.pcust);
         break;
       }
     }
 }
    
 onSubmit(){
  //  this.CustomerObj = {
  //      "id":customerData.id,
  //   "first_name" : customerData.first_name,
  //   "last_name" : customerData.last_name,
  //   "gender":customerData.gender,
  //   "address" : customerData.address,
  //   "city" : customerData.city,
  //   "state" : customerData.state
  //  }     
  this.service.updateCustomer(this.pcust).subscribe(data=> alert('Successfully Updated!!'),error=> alert('Error!!'));
  //  console.log(customerData);
  //  this.http.post(this.url , this.CustomerObj).subscribe(res => {console.log(res);this.isAdded=true;})
// sampledata.push(this.CustomerObj);
 }
  
  
}