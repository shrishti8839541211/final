import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { CustomerComponent } from './customer.component';
import { UpdateFormComponent } from './updateform.component';
import { AddNewCustomerComponent } from './addnewcustomer.component';
import { CustomersService } from './customers.service';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', component: CustomerComponent },
  { path: 'addnewcustomer', component: AddNewCustomerComponent  },
  { path: 'update/:id', component: UpdateFormComponent  }
];

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    AddNewCustomerComponent,
    UpdateFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [CustomersService],
  bootstrap: [AppComponent]
})
export class AppModule { }


