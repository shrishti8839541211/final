import { Component , OnInit } from '@angular/core';
import { Customers } from './customers';
import { CustomersService } from './customers.service';
// import sampledata from '../assets/data.json';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
  providers:[CustomersService]
})
export class CustomerComponent implements OnInit{
  public custom=[];
  confirmDelete:boolean=true;
  constructor(private service:CustomersService) { 
    // this.custom=this.service.getCustomers();
  }

  ngOnInit(){
    this.service.getCustomer().subscribe((res)=>this.custom=res);
    // console.log(this.custom);this.fetchdata()
  }

  removeCustomer(index:number):void{
  var res = confirm("Are You Sure You Want To Delete?");
  if (res == true) {
    this.service.remove(index).subscribe(()=>console.log('Customer Delete: '+index));
  }
}

doSearch(serachStr:string){
  var prodNames: string[] = [];
  for(var i in this.custom){
      if(this.custom[i].first_name.toLowerCase().
      startsWith(serachStr.toLowerCase())){
          prodNames[i] = this.custom[i].first_name;
      }
  }
  alert(prodNames);
  // console.log(prodNames);
}

}
